from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load trained model
model = joblib.load("lung_model.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get input values from form
        age = int(request.form["age"])
        gender = 1 if request.form["gender"] == "male" else 0
        smoking = 1 if request.form["smoking"] == "yes" else 0
        alcohol = 1 if request.form["alcohol"] == "yes" else 0
        chest_pain = 1 if request.form["chest_pain"] == "yes" else 0
        coughing = 1 if request.form["coughing"] == "yes" else 0

        # Prepare features
        features = np.array([[age, gender, smoking, alcohol, chest_pain, coughing]])
        
        # Prediction
        prediction = model.predict(features)[0]
        result = "✅ Yes (Risk of Cancer)" if prediction == 1 else "❌ No (No Risk)"

        return render_template("index.html", prediction_text=f"Prediction: {result}")

    except Exception as e:
        return render_template("index.html", prediction_text=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)